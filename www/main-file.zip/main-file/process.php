<?php

		$to = "email@example.com";
		$from =  $_POST["email"];
		$message = "&nbsp;&nbsp;&nbsp;&nbsp;<strong>Name: </strong>".$_POST["name"]."<br />";
		$message .= "&nbsp;&nbsp;&nbsp;&nbsp;<strong>Email Address: </strong>".$_POST["email"]."<br />";
		$message .= "&nbsp;&nbsp;&nbsp;&nbsp;<strong>Company: </strong>".$_POST["company"]."<br />";
		$message .= "&nbsp;&nbsp;&nbsp;&nbsp; <strong>Website: </strong>".$_POST["website"]."<br />";
		$message .= "&nbsp;&nbsp;&nbsp;&nbsp; <strong>Message: </strong>".$_POST["message"]."<br />";
		$subject = 'RockoX - Contact Enquiry';		
		$headers = "From:".$_POST["name"]. "<".$_POST["email"].">\n";
		$headers .= "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
		
	    $send =	mail($to,$subject,$message,$headers);



if($send)
{
	echo "success";
}
else
{
	echo "error";
}
?>